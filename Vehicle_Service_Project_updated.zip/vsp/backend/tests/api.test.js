// Run with the server and database running:  npm test
// Optional: API_URL=http://localhost:5000/api npm test
const test = require('node:test');
const assert = require('node:assert');
const BASE = process.env.API_URL || 'http://localhost:5000/api';
const email = `test${Date.now()}@demo.com`;
const ctx = {};

async function call(path, method = 'GET', body, token) {
  const r = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token && { Authorization: 'Bearer ' + token }) },
    body: body && JSON.stringify(body)
  });
  return { status: r.status, data: await r.json().catch(() => ({})) };
}
const today = new Date().toISOString().slice(0, 10);

test('rejects invalid registration', async () => {
  assert.strictEqual((await call('/auth/register', 'POST', { name: 'A', email: 'bad', password: '1' })).status, 400);
});
test('register and login a customer', async () => {
  const r = await call('/auth/register', 'POST', { name: 'Test User', email, password: 'secret1' });
  assert.strictEqual(r.status, 201);
  ctx.user = r.data.token;
  assert.strictEqual((await call('/auth/login', 'POST', { email, password: 'wrong' })).status, 401);
});
test('protected routes need a token', async () => {
  assert.strictEqual((await call('/vehicles')).status, 401);
});
test('customer cannot use admin routes', async () => {
  assert.strictEqual((await call('/technicians', 'GET', null, ctx.user)).status, 403);
});
test('register vehicle and book a service', async () => {
  const reg = 'TS' + String(Date.now()).slice(-8);
  assert.strictEqual((await call('/vehicles', 'POST', { registration_no: reg, model: 'Swift' }, ctx.user)).status, 201);
  const [v] = (await call('/vehicles', 'GET', null, ctx.user)).data;
  const [s] = (await call('/services', 'GET', null, ctx.user)).data;
  assert.strictEqual((await call('/bookings', 'POST', { vehicle_id: v.vehicle_id, service_id: s.service_id, booking_date: '2000-01-01' }, ctx.user)).status, 400);
  const b = await call('/bookings', 'POST', { vehicle_id: v.vehicle_id, service_id: s.service_id, booking_date: today }, ctx.user);
  assert.strictEqual(b.status, 201);
  ctx.booking = b.data.booking_id;
});
test('admin completes the job and generates an invoice', async () => {
  const a = await call('/auth/login', 'POST', { email: 'admin@service.com', password: 'admin123' });
  assert.strictEqual(a.status, 200);
  ctx.admin = a.data.token;
  const [t] = (await call('/technicians', 'GET', null, ctx.admin)).data;
  assert.strictEqual((await call(`/bookings/${ctx.booking}/assign`, 'PUT', { technician_id: t.technician_id }, ctx.admin)).status, 200);
  assert.strictEqual((await call('/invoices', 'POST', { booking_id: ctx.booking }, ctx.admin)).status, 400); // not completed yet
  assert.strictEqual((await call(`/bookings/${ctx.booking}/status`, 'PUT', { status: 'Nonsense' }, ctx.admin)).status, 400);
  assert.strictEqual((await call(`/bookings/${ctx.booking}/status`, 'PUT', { status: 'Completed' }, ctx.admin)).status, 200);
  assert.strictEqual((await call('/invoices', 'POST', { booking_id: ctx.booking }, ctx.admin)).status, 201);
  assert.strictEqual((await call('/invoices', 'POST', { booking_id: ctx.booking }, ctx.admin)).status, 409); // duplicate
});
test('customer pays the invoice once', async () => {
  const [b] = (await call('/bookings', 'GET', null, ctx.user)).data;
  assert.ok(b.invoice_id);
  const order = await call('/payments/order', 'POST', { invoice_id: b.invoice_id }, ctx.user);
  assert.strictEqual(order.status, 200);
  if (order.data.mode === 'simulated') {
    assert.strictEqual((await call('/payments', 'POST', { invoice_id: b.invoice_id, method: 'UPI' }, ctx.user)).status, 200);
    assert.strictEqual((await call('/payments', 'POST', { invoice_id: b.invoice_id, method: 'UPI' }, ctx.user)).status, 409);
  }
});
test('customer received notifications', async () => {
  const n = await call('/notifications', 'GET', null, ctx.user);
  assert.ok(n.data.length >= 3);
});
