// Creates the demo admin and customer accounts (run after schema.sql)
require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./src/db');
(async () => {
  const add = async (n, e, p, role, pw) =>
    db.query('INSERT IGNORE INTO customer(name,email,phone,password_hash,role) VALUES (?,?,?,?,?)', [n, e, p, await bcrypt.hash(pw, 10), role]);
  await add('Service Center Admin', 'admin@service.com', '9999999999', 'admin', 'admin123');
  await add('Demo Customer', 'user@demo.com', '8888888888', 'customer', 'user123');
  console.log('Seeded: admin@service.com / admin123   user@demo.com / user123');
  process.exit(0);
})().catch(e => { console.error(e.message); process.exit(1); });
