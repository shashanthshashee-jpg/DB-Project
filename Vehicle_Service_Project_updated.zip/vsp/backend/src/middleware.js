const jwt = require('jsonwebtoken');
const bad = (msg, status = 400) => Object.assign(new Error(msg), { status });
const wrap = fn => (req, res, next) => fn(req, res, next).catch(next);
const auth = (req, res, next) => {
  try { req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), process.env.JWT_SECRET); next(); }
  catch { next(bad('Please log in', 401)); }
};
const role = r => (req, res, next) => (req.user.role === r ? next() : next(bad('Not allowed', 403)));
module.exports = { bad, wrap, auth, role };
