const router = require('express').Router();
const rateLimit = require('express-rate-limit');
const { wrap, auth, role } = require('../middleware');
const authC = require('../controllers/auth.controller');
const vehicleC = require('../controllers/vehicle.controller');
const bookingC = require('../controllers/booking.controller');
const billingC = require('../controllers/billing.controller');

const admin = [auth, role('admin')];
const authLimit = rateLimit({ windowMs: 15 * 60 * 1000, max: 50 });

// Auth
router.post('/auth/register', authLimit, wrap(authC.register));
router.post('/auth/login', authLimit, wrap(authC.login));
// Catalogue
router.get('/services', auth, wrap(bookingC.services));
router.get('/technicians', admin, wrap(bookingC.technicians));
router.get('/parts', admin, wrap(bookingC.parts));
// Vehicles
router.get('/vehicles', auth, wrap(vehicleC.list));
router.post('/vehicles', auth, wrap(vehicleC.create));
// Bookings
router.get('/bookings', auth, wrap(bookingC.list));
router.post('/bookings', auth, wrap(bookingC.create));
router.put('/bookings/:id/status', admin, wrap(bookingC.setStatus));
router.put('/bookings/:id/assign', admin, wrap(bookingC.assign));
router.post('/bookings/:id/parts', admin, wrap(bookingC.addPart));
// Invoices and payments
router.post('/invoices', admin, wrap(billingC.invoice));
router.post('/payments/order', auth, wrap(billingC.order));
router.post('/payments/verify', auth, wrap(billingC.verify));
router.post('/payments', auth, wrap(billingC.pay));
// Dashboard and notifications
router.get('/stats', admin, wrap(billingC.stats));
router.get('/notifications', auth, wrap(billingC.notifications));
router.put('/notifications/read', auth, wrap(billingC.readAll));
router.post('/notifications/token', auth, wrap(billingC.saveToken));

module.exports = router;
