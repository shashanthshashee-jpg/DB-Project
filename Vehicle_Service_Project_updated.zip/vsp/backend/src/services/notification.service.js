const db = require('../db');
let fcm; // undefined = not tried yet, false = disabled
function push() {
  if (fcm !== undefined) return fcm;
  fcm = false;
  if (!process.env.FIREBASE_SERVICE_ACCOUNT) return fcm;
  try {
    const fb = require('firebase-admin');
    fb.initializeApp({ credential: fb.credential.cert(require(require('path').resolve(process.env.FIREBASE_SERVICE_ACCOUNT))) });
    fcm = fb;
  } catch (e) { console.warn('FCM disabled:', e.message); }
  return fcm;
}
// Saves an in-app notification and, if Firebase is configured, also sends an FCM push
exports.notify = async (customerId, message, conn = db) => {
  await conn.query('INSERT INTO notification(customer_id,message) VALUES (?,?)', [customerId, message]);
  const f = push();
  if (!f) return;
  try {
    const [[u]] = await db.query('SELECT fcm_token FROM customer WHERE customer_id=?', [customerId]);
    if (u && u.fcm_token) await f.messaging().send({ token: u.fcm_token, notification: { title: 'Vehicle Service', body: message } });
  } catch (e) { console.warn('FCM send failed:', e.message); }
};
exports.list = async userId =>
  (await db.query('SELECT notification_id, message, is_read, created_at FROM notification WHERE customer_id=? ORDER BY notification_id DESC LIMIT 20', [userId]))[0];
exports.markAllRead = userId => db.query('UPDATE notification SET is_read=TRUE WHERE customer_id=?', [userId]);
exports.saveToken = (userId, token) => db.query('UPDATE customer SET fcm_token=? WHERE customer_id=?', [token, userId]);
