const crypto = require('crypto');
const db = require('../db');
const { bad } = require('../middleware');
const { notify } = require('./notification.service');

const razorpayOn = () => !!(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET);

exports.generateInvoice = async bookingId => {
  try {
    await db.query('CALL sp_generate_invoice(?)', [bookingId]);
    const [[o]] = await db.query('SELECT v.customer_id FROM booking b JOIN vehicle v ON v.vehicle_id=b.vehicle_id WHERE b.booking_id=?', [bookingId]);
    if (o) await notify(o.customer_id, `Invoice generated for booking #${bookingId}. Please pay online.`);
  } catch (e) {
    if (e.sqlState === '45000') throw bad(e.sqlMessage);
    throw e.code === 'ER_DUP_ENTRY' ? bad('Invoice already exists', 409) : e;
  }
};

const ownedInvoice = async (c, invoiceId, userId) => {
  const [[inv]] = await c.query(
    `SELECT i.invoice_id, i.total, i.status, i.gateway_order_id FROM invoice i
     JOIN booking b ON b.booking_id=i.booking_id JOIN vehicle v ON v.vehicle_id=b.vehicle_id
     WHERE i.invoice_id=? AND v.customer_id=? FOR UPDATE`, [invoiceId, userId]);
  if (!inv) throw bad('Invoice not found', 404);
  if (inv.status === 'Paid') throw bad('Invoice already paid', 409);
  return inv;
};

// Payment row + invoice status change happen in one transaction
const record = (userId, invoiceId, method, check, gatewayPaymentId = null) =>
  db.tx(async c => {
    const inv = await ownedInvoice(c, invoiceId, userId);
    if (check) check(inv);
    await c.query('INSERT INTO payment(invoice_id,amount,method,gateway_payment_id) VALUES (?,?,?,?)', [inv.invoice_id, inv.total, method, gatewayPaymentId]);
    await c.query("UPDATE invoice SET status='Paid' WHERE invoice_id=?", [inv.invoice_id]);
    await notify(userId, `Payment of ₹${inv.total} received for invoice #${inv.invoice_id}. Thank you!`, c);
  });

// Step 1: create a Razorpay order (or tell the client to use the simulated payment)
exports.createOrder = async (userId, invoiceId) => {
  const inv = await ownedInvoice(db, invoiceId, userId);
  if (!razorpayOn()) return { mode: 'simulated' };
  const auth = Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString('base64');
  const res = await fetch('https://api.razorpay.com/v1/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Basic ' + auth },
    body: JSON.stringify({ amount: Math.round(Number(inv.total) * 100), currency: 'INR', receipt: 'inv_' + inv.invoice_id })
  });
  if (!res.ok) throw bad('Payment gateway error', 502);
  const o = await res.json();
  await db.query('UPDATE invoice SET gateway_order_id=? WHERE invoice_id=?', [o.id, inv.invoice_id]);
  return { mode: 'razorpay', order_id: o.id, amount: o.amount, key_id: process.env.RAZORPAY_KEY_ID };
};

// Step 2: verify Razorpay's signature, then record the payment
exports.verify = async (userId, { invoice_id, razorpay_order_id, razorpay_payment_id, razorpay_signature }) => {
  if (!razorpayOn()) throw bad('Razorpay is not configured', 400);
  const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
  const a = Buffer.from(expected), b = Buffer.from(String(razorpay_signature || ''));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw bad('Payment verification failed', 400);
  await record(userId, invoice_id, 'Razorpay', inv => {
    if (inv.gateway_order_id !== razorpay_order_id) throw bad('Order does not match this invoice', 400);
  }, razorpay_payment_id);
};

// Simulated payment, only when Razorpay keys are not set (demo / viva mode)
exports.paySimulated = async (userId, invoiceId, method) => {
  if (razorpayOn()) throw bad('Use Razorpay checkout to pay', 400);
  await record(userId, invoiceId, method || 'UPI', null);
};
