const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { bad } = require('../middleware');

const sign = u => jwt.sign({ id: u.customer_id, role: u.role, name: u.name }, process.env.JWT_SECRET, { expiresIn: '8h' });

exports.register = async ({ name, email, phone, password }) => {
  try {
    const [r] = await db.query('INSERT INTO customer(name,email,phone,password_hash) VALUES (?,?,?,?)',
      [name, email, phone || null, await bcrypt.hash(password, 10)]);
    return { token: sign({ customer_id: r.insertId, name, role: 'customer' }), user: { name, role: 'customer' } };
  } catch (e) { throw e.code === 'ER_DUP_ENTRY' ? bad('Email already registered', 409) : e; }
};
exports.login = async ({ email, password }) => {
  const [[u]] = await db.query('SELECT * FROM customer WHERE email=?', [email || '']);
  if (!u || !(await bcrypt.compare(password || '', u.password_hash))) throw bad('Wrong email or password', 401);
  return { token: sign(u), user: { name: u.name, role: u.role } };
};
