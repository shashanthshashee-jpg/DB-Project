const db = require('../db');
const { bad } = require('../middleware');
const { notify } = require('./notification.service');

const owner = async id => {
  const [[o]] = await db.query(
    `SELECT v.customer_id, s.service_name FROM booking b JOIN vehicle v ON v.vehicle_id=b.vehicle_id
     JOIN service s ON s.service_id=b.service_id WHERE b.booking_id=?`, [id]);
  if (!o) throw bad('Booking not found', 404);
  return o;
};

exports.services = async () => (await db.query('SELECT * FROM service'))[0];
exports.technicians = async () => (await db.query('SELECT * FROM technician'))[0];
exports.parts = async () => (await db.query('SELECT * FROM spare_part'))[0];

exports.list = async user =>
  (user.role === 'admin'
    ? await db.query('SELECT * FROM v_booking_details ORDER BY booking_id DESC')
    : await db.query('SELECT * FROM v_booking_details WHERE customer_id=? ORDER BY booking_id DESC', [user.id]))[0];

exports.create = async (user, { vehicle_id, service_id, booking_date }) => {
  const [[own]] = await db.query('SELECT 1 AS ok FROM vehicle WHERE vehicle_id=? AND customer_id=?', [vehicle_id, user.id]);
  if (!own) throw bad('Vehicle not found', 404);
  const [r] = await db.query('INSERT INTO booking(vehicle_id,service_id,booking_date) VALUES (?,?,?)', [vehicle_id, service_id, booking_date]);
  await notify(user.id, `Booking #${r.insertId} received for ${booking_date}.`);
  return { booking_id: r.insertId };
};

exports.setStatus = async (id, status) => {
  const o = await owner(id);
  await db.query('UPDATE booking SET status=? WHERE booking_id=?', [status, id]);
  await notify(o.customer_id, `Your ${o.service_name} booking #${id} is now ${status}.`);
};

exports.assign = async (id, technicianId) => {
  const o = await owner(id);
  await db.query('UPDATE booking SET technician_id=? WHERE booking_id=?', [technicianId || null, id]);
  if (technicianId) {
    const [[t]] = await db.query('SELECT name FROM technician WHERE technician_id=?', [technicianId]);
    if (t) await notify(o.customer_id, `${t.name} is assigned to your booking #${id}.`);
  }
};

// Transaction: reduce stock and record the part together, or neither
exports.addPart = async (id, partId, quantity) => {
  await db.tx(async c => {
    const [u] = await c.query('UPDATE spare_part SET stock=stock-? WHERE part_id=? AND stock>=?', [quantity, partId, quantity]);
    if (!u.affectedRows) throw bad('Not enough stock');
    await c.query('INSERT INTO job_part(booking_id,part_id,quantity) VALUES (?,?,?) ON DUPLICATE KEY UPDATE quantity=quantity+VALUES(quantity)',
      [id, partId, quantity]);
  });
};
