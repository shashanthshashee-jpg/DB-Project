const db = require('../db');
const { bad } = require('../middleware');

exports.list = async user =>
  (user.role === 'admin' ? await db.query('SELECT * FROM vehicle') : await db.query('SELECT * FROM vehicle WHERE customer_id=?', [user.id]))[0];
exports.create = async (userId, { registration_no, model }) => {
  try {
    const [r] = await db.query('INSERT INTO vehicle(customer_id,registration_no,model) VALUES (?,?,?)',
      [userId, registration_no.trim().toUpperCase(), model]);
    return { vehicle_id: r.insertId };
  } catch (e) { throw e.code === 'ER_DUP_ENTRY' ? bad('Vehicle already registered', 409) : e; }
};
