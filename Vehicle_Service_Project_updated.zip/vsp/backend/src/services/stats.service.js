const db = require('../db');

exports.dashboard = async () => {
  const [byStatus] = await db.query('SELECT status, COUNT(*) AS total FROM booking GROUP BY status');
  const [[rev]] = await db.query("SELECT IFNULL(SUM(total),0) AS revenue FROM invoice WHERE status='Paid'");
  const [top] = await db.query(
    `WITH spend AS (
       SELECT c.name, SUM(i.total) AS amount FROM invoice i
       JOIN booking b ON b.booking_id=i.booking_id JOIN vehicle v ON v.vehicle_id=b.vehicle_id
       JOIN customer c ON c.customer_id=v.customer_id GROUP BY c.customer_id, c.name)
     SELECT name, amount, RANK() OVER (ORDER BY amount DESC) AS pos FROM spend LIMIT 5`);
  return { byStatus, revenue: rev.revenue, top };
};
