const billing = require('../services/billing.service');
const stats = require('../services/stats.service');
const notifications = require('../services/notification.service');
const { bad } = require('../middleware');

exports.invoice = async (req, res) => {
  if (!req.body.booking_id) throw bad('Booking is required');
  await billing.generateInvoice(req.body.booking_id);
  res.status(201).json({ ok: true });
};
exports.order = async (req, res) => res.json(await billing.createOrder(req.user.id, req.body.invoice_id));
exports.verify = async (req, res) => { await billing.verify(req.user.id, req.body); res.json({ ok: true }); };
exports.pay = async (req, res) => { await billing.paySimulated(req.user.id, req.body.invoice_id, req.body.method); res.json({ ok: true }); };
exports.stats = async (req, res) => res.json(await stats.dashboard());

exports.notifications = async (req, res) => res.json(await notifications.list(req.user.id));
exports.readAll = async (req, res) => { await notifications.markAllRead(req.user.id); res.json({ ok: true }); };
exports.saveToken = async (req, res) => {
  if (!req.body.token) throw bad('Token is required');
  await notifications.saveToken(req.user.id, req.body.token);
  res.json({ ok: true });
};
