const bookings = require('../services/booking.service');
const { bad } = require('../middleware');

const STATUSES = ['Booked', 'In Progress', 'Completed', 'Cancelled'];
exports.services = async (req, res) => res.json(await bookings.services());
exports.technicians = async (req, res) => res.json(await bookings.technicians());
exports.parts = async (req, res) => res.json(await bookings.parts());
exports.list = async (req, res) => res.json(await bookings.list(req.user));
exports.create = async (req, res) => {
  const { vehicle_id, service_id, booking_date } = req.body;
  if (!vehicle_id || !service_id || !/^\d{4}-\d{2}-\d{2}$/.test(booking_date || '')) throw bad('Vehicle, service and date are required');
  if (booking_date < new Date().toISOString().slice(0, 10)) throw bad('Choose today or a future date');
  res.status(201).json(await bookings.create(req.user, req.body));
};
exports.setStatus = async (req, res) => {
  if (!STATUSES.includes(req.body.status)) throw bad('Invalid status');
  await bookings.setStatus(req.params.id, req.body.status);
  res.json({ ok: true });
};
exports.assign = async (req, res) => { await bookings.assign(req.params.id, req.body.technician_id); res.json({ ok: true }); };
exports.addPart = async (req, res) => {
  const { part_id, quantity } = req.body;
  if (!part_id || !(quantity > 0)) throw bad('Part and quantity are required');
  await bookings.addPart(req.params.id, part_id, quantity);
  res.json({ ok: true });
};
