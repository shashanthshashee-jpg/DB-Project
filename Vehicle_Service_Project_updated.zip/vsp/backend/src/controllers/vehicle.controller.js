const vehicles = require('../services/vehicle.service');
const { bad } = require('../middleware');

exports.list = async (req, res) => res.json(await vehicles.list(req.user));
exports.create = async (req, res) => {
  if (!req.body.registration_no || !req.body.model) throw bad('Registration number and model are required');
  res.status(201).json(await vehicles.create(req.user.id, req.body));
};
