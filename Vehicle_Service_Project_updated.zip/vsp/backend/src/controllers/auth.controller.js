const auth = require('../services/auth.service');
const { bad } = require('../middleware');

exports.register = async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !/^\S+@\S+\.\S+$/.test(email || '') || !password || password.length < 6)
    throw bad('Name, a valid email and a password of 6+ characters are required');
  res.status(201).json(await auth.register(req.body));
};
exports.login = async (req, res) => res.json(await auth.login(req.body));
