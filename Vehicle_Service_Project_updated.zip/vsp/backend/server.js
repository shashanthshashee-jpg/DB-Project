require('dotenv').config();
const fs = require('fs');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const routes = require('./src/routes');

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use('/api', rateLimit({ windowMs: 60 * 1000, max: 300 }), routes);
app.use((err, req, res, next) => {
  if (!err.status) console.error(err);
  res.status(err.status || 500).json({ error: err.status ? err.message : 'Server error' });
});

const port = process.env.PORT || 5000;
// HTTPS is switched on when a key and certificate are provided in .env
if (process.env.SSL_KEY_FILE && process.env.SSL_CERT_FILE) {
  require('https').createServer({ key: fs.readFileSync(process.env.SSL_KEY_FILE), cert: fs.readFileSync(process.env.SSL_CERT_FILE) }, app)
    .listen(port, () => console.log('API running on https://localhost:' + port));
} else {
  app.listen(port, () => console.log('API running on http://localhost:' + port));
}
module.exports = app;
