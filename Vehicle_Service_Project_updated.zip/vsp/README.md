# Vehicle Service Booking and Tracking System

React.js + Node.js/Express.js + MySQL. Runs from VS Code.

## Setup (once)
1. Install Node.js 18+ and MySQL 8+.
2. Create the database. In MySQL Workbench open `database/schema.sql` and run it.
   Or in Command Prompt: `mysql -u root -p < database/schema.sql`
3. Backend: open a VS Code terminal.
   ```
   cd backend
   copy .env.example .env      (Mac/Linux: cp .env.example .env)
   ```
   Edit `.env`: set `DB_PASSWORD` and a long random `JWT_SECRET`.
   ```
   npm install
   npm run seed
   npm start
   ```
4. Frontend: open a second terminal.
   ```
   cd frontend
   npm install
   npm run dev
   ```
5. Open http://localhost:5173

## Demo logins
- Service center: admin@service.com / admin123
- Customer: user@demo.com / user123

## Demo flow
Customer: register a vehicle, book a service. Admin: assign a technician, add spare parts, set status to In Progress then Completed, generate the invoice. Customer: watch the status bar and notifications, then pay.

## Backend structure
`routes/` (URLs + middleware) -> `controllers/` (validation, HTTP) -> `services/` (business logic and SQL) -> MySQL.

## Where each concept lives
- ER design, constraints, indexes, view, trigger, stored procedure: `database/schema.sql`
- Transactions: `services/booking.service.js` (add part), `services/billing.service.js` (payment), `db.js`
- CTE and window function (RANK): `services/stats.service.js` (`GET /api/stats`)
- JWT, role-based access, hashing, rate limiting, validation: `middleware.js`, `controllers/`, `routes/`, `server.js`

## Optional features (set in backend/.env)
- **Razorpay payments:** put your *test* `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` in `.env` and restart. The Pay button then opens Razorpay Checkout (test card/UPI) and the server verifies the signature. Without keys, payment is simulated.
- **Notifications:** every booking, status change, technician assignment, invoice and payment creates an in-app notification (bell in the header). For FCM push: `npm install firebase-admin`, set `FIREBASE_SERVICE_ACCOUNT` to your service-account JSON path, and send the device token to `POST /api/notifications/token`.
- **HTTPS:** create a certificate and set `SSL_KEY_FILE` and `SSL_CERT_FILE`:
  `openssl req -x509 -newkey rsa:2048 -nodes -keyout key.pem -out cert.pem -days 365 -subj "/CN=localhost"`
  (for local dev with the Vite proxy, change its target in `frontend/vite.config.js` to `https://localhost:5000` with `secure: false`).

## Testing
- Automated: with the server running, `cd backend && npm test`
- Postman: import `docs/postman_collection.json`, run the collection (it chains register, login, booking, invoice and payment).
