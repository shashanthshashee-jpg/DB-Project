import { useEffect, useState, useCallback } from 'react';
import { api, setToken } from './api';
import { payInvoice } from './pay';
import './styles.css';

const STEPS = ['Booked', 'In Progress', 'Completed'];
const money = n => '₹' + Number(n).toLocaleString('en-IN');

function useLoad(paths) {
  const [data, setData] = useState({});
  const [error, setError] = useState('');
  const load = useCallback(async () => {
    try {
      const out = {};
      await Promise.all(Object.entries(paths).map(async ([k, p]) => { out[k] = await api(p); }));
      setData(out);
    } catch (e) { setError(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);
  return [data, load, error, setError];
}

function StatusBar({ status }) {
  if (status === 'Cancelled') return <p className="cancelled">Cancelled</p>;
  const at = STEPS.indexOf(status);
  return <ol className="steps">{STEPS.map((s, i) => <li key={s} className={i <= at ? 'done' : ''}>{s}</li>)}</ol>;
}

function Bell() {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const load = () => api('/notifications').then(setItems).catch(() => {});
  useEffect(() => { load(); const t = setInterval(load, 15000); return () => clearInterval(t); }, []);
  const unread = items.filter(n => !n.is_read).length;
  const toggle = async () => { setOpen(!open); if (!open && unread) { await api('/notifications/read', 'PUT'); load(); } };
  return (
    <div className="bell">
      <button className="ghost" onClick={toggle}>Notifications{unread > 0 && ` (${unread})`}</button>
      {open && <ul>{items.length === 0 ? <li>No notifications</li> : items.map(n => <li key={n.notification_id}>{n.message}<small>{new Date(n.created_at).toLocaleString()}</small></li>)}</ul>}
    </div>
  );
}

function Auth({ onDone }) {
  const [mode, setMode] = useState('login');
  const [f, setF] = useState({ name: '', email: '', phone: '', password: '' });
  const [error, setError] = useState('');
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const submit = async e => {
    e.preventDefault();
    try {
      const d = await api('/auth/' + mode, 'POST', f);
      setToken(d.token); localStorage.setItem('user', JSON.stringify(d.user)); onDone(d.user);
    } catch (err) { setError(err.message); }
  };
  return (
    <main className="auth">
      <h1>Vehicle Service Center</h1>
      <p className="sub">Book a service and follow it until the invoice is paid.</p>
      <form onSubmit={submit}>
        {mode === 'register' && <>
          <label>Name<input value={f.name} onChange={set('name')} required /></label>
          <label>Phone<input value={f.phone} onChange={set('phone')} /></label>
        </>}
        <label>Email<input type="email" value={f.email} onChange={set('email')} required /></label>
        <label>Password<input type="password" value={f.password} onChange={set('password')} required /></label>
        {error && <p className="error">{error}</p>}
        <button>{mode === 'login' ? 'Log in' : 'Create account'}</button>
        <button type="button" className="ghost" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }}>
          {mode === 'login' ? 'Need an account? Register' : 'Have an account? Log in'}
        </button>
      </form>
    </main>
  );
}

function Customer() {
  const [d, load, error, setError] = useLoad({ vehicles: '/vehicles', services: '/services', bookings: '/bookings' });
  const [v, setV] = useState({ registration_no: '', model: '' });
  const [b, setB] = useState({ vehicle_id: '', service_id: '', booking_date: '' });
  const act = fn => async e => { e?.preventDefault(); try { await fn(); setError(''); load(); } catch (err) { setError(err.message); } };
  return (
    <>
      {error && <p className="error">{error}</p>}
      <section className="grid">
        <form onSubmit={act(async () => { await api('/vehicles', 'POST', v); setV({ registration_no: '', model: '' }); })}>
          <h2>Register a vehicle</h2>
          <label>Registration number<input value={v.registration_no} onChange={e => setV({ ...v, registration_no: e.target.value })} required /></label>
          <label>Model<input value={v.model} onChange={e => setV({ ...v, model: e.target.value })} required /></label>
          <button>Save vehicle</button>
        </form>
        <form onSubmit={act(async () => { await api('/bookings', 'POST', b); })}>
          <h2>Book a service</h2>
          <label>Vehicle<select value={b.vehicle_id} onChange={e => setB({ ...b, vehicle_id: e.target.value })} required>
            <option value="">Select</option>{(d.vehicles || []).map(x => <option key={x.vehicle_id} value={x.vehicle_id}>{x.registration_no} – {x.model}</option>)}
          </select></label>
          <label>Service<select value={b.service_id} onChange={e => setB({ ...b, service_id: e.target.value })} required>
            <option value="">Select</option>{(d.services || []).map(x => <option key={x.service_id} value={x.service_id}>{x.service_name} – {money(x.base_price)}</option>)}
          </select></label>
          <label>Date<input type="date" value={b.booking_date} onChange={e => setB({ ...b, booking_date: e.target.value })} required /></label>
          <button>Book service</button>
        </form>
      </section>
      <h2>My bookings</h2>
      {(d.bookings || []).length === 0 && <p className="empty">No bookings yet. Register a vehicle and book your first service.</p>}
      <div className="list">
        {(d.bookings || []).map(x => (
          <article key={x.booking_id}>
            <div className="row"><strong>{x.service_name}</strong><span>{x.registration_no} · {x.model}</span><span>{String(x.booking_date).slice(0, 10)}</span></div>
            <StatusBar status={x.status} />
            <p className="meta">Technician: {x.technician_name || 'Not assigned yet'}</p>
            {x.invoice_id && <div className="row">
              <span>Invoice {money(x.total)} – {x.invoice_status}</span>
              {x.invoice_status === 'Unpaid' && <button onClick={act(() => payInvoice(x.invoice_id))}>Pay now</button>}
            </div>}
          </article>
        ))}
      </div>
    </>
  );
}

function Admin() {
  const [d, load, error, setError] = useLoad({ bookings: '/bookings', technicians: '/technicians', parts: '/parts', stats: '/stats' });
  const [part, setPart] = useState({});
  const act = fn => async () => { try { await fn(); setError(''); load(); } catch (err) { setError(err.message); } };
  const s = d.stats;
  return (
    <>
      {error && <p className="error">{error}</p>}
      {s && <section className="stats">
        <div><b>{money(s.revenue)}</b><span>Paid revenue</span></div>
        {s.byStatus.map(x => <div key={x.status}><b>{x.total}</b><span>{x.status}</span></div>)}
        <div className="wide"><span>Top customers</span>{s.top.length === 0 ? <i>No invoices yet</i> : s.top.map(t => <p key={t.name}>{t.pos}. {t.name} – {money(t.amount)}</p>)}</div>
      </section>}
      <h2>All bookings</h2>
      <div className="list">
        {(d.bookings || []).map(x => (
          <article key={x.booking_id}>
            <div className="row"><strong>#{x.booking_id} {x.service_name}</strong><span>{x.customer_name} · {x.registration_no}</span><span>{String(x.booking_date).slice(0, 10)}</span></div>
            <div className="row">
              <label>Status<select value={x.status} onChange={e => act(() => api(`/bookings/${x.booking_id}/status`, 'PUT', { status: e.target.value }))()}>
                {['Booked', 'In Progress', 'Completed', 'Cancelled'].map(o => <option key={o}>{o}</option>)}</select></label>
              <label>Technician<select value={x.technician_id || ''} onChange={e => act(() => api(`/bookings/${x.booking_id}/assign`, 'PUT', { technician_id: e.target.value }))()}>
                <option value="">Unassigned</option>{(d.technicians || []).map(t => <option key={t.technician_id} value={t.technician_id}>{t.name}</option>)}</select></label>
            </div>
            <div className="row">
              <select value={part[x.booking_id]?.id || ''} onChange={e => setPart({ ...part, [x.booking_id]: { ...part[x.booking_id], id: e.target.value } })}>
                <option value="">Add spare part</option>{(d.parts || []).map(p => <option key={p.part_id} value={p.part_id}>{p.part_name} ({p.stock} in stock)</option>)}</select>
              <input type="number" min="1" placeholder="Qty" value={part[x.booking_id]?.qty || ''} onChange={e => setPart({ ...part, [x.booking_id]: { ...part[x.booking_id], qty: e.target.value } })} />
              <button className="ghost" onClick={act(() => api(`/bookings/${x.booking_id}/parts`, 'POST', { part_id: part[x.booking_id]?.id, quantity: Number(part[x.booking_id]?.qty) }))}>Add part</button>
              {x.invoice_id
                ? <span>Invoice {money(x.total)} – {x.invoice_status}</span>
                : <button onClick={act(() => api('/invoices', 'POST', { booking_id: x.booking_id }))}>Generate invoice</button>}
            </div>
          </article>
        ))}
      </div>
    </>
  );
}

export default function App() {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('user') || 'null'));
  if (!user) return <Auth onDone={setUser} />;
  return (
    <div className="shell">
      <header>
        <h1>Vehicle Service Center</h1>
        <div className="who"><Bell />{user.name} ({user.role}) <button className="ghost" onClick={() => { setToken(null); localStorage.removeItem('user'); setUser(null); }}>Log out</button></div>
      </header>
      {user.role === 'admin' ? <Admin /> : <Customer />}
    </div>
  );
}
