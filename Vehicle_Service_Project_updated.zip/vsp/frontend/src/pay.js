import { api } from './api';

function loadCheckout() {
  return new Promise((resolve, reject) => {
    if (window.Razorpay) return resolve();
    const s = document.createElement('script');
    s.src = 'https://checkout.razorpay.com/v1/checkout.js';
    s.onload = resolve;
    s.onerror = () => reject(new Error('Could not load Razorpay checkout'));
    document.body.appendChild(s);
  });
}

// Razorpay checkout when keys are configured on the server, otherwise the simulated payment
export async function payInvoice(invoiceId) {
  const o = await api('/payments/order', 'POST', { invoice_id: invoiceId });
  if (o.mode === 'simulated') return api('/payments', 'POST', { invoice_id: invoiceId, method: 'UPI' });
  await loadCheckout();
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  return new Promise((resolve, reject) => {
    new window.Razorpay({
      key: o.key_id, amount: o.amount, currency: 'INR', order_id: o.order_id,
      name: 'Vehicle Service Center', prefill: { name: user.name },
      handler: r => api('/payments/verify', 'POST', { invoice_id: invoiceId, ...r }).then(resolve, reject),
      modal: { ondismiss: () => reject(new Error('Payment cancelled')) }
    }).open();
  });
}
