-- Run: mysql -u root -p < database/schema.sql
DROP DATABASE IF EXISTS vehicle_service;
CREATE DATABASE vehicle_service;
USE vehicle_service;

CREATE TABLE customer (
  customer_id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  phone VARCHAR(15),
  password_hash VARCHAR(100) NOT NULL,
  role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  fcm_token VARCHAR(255) NULL
);
CREATE TABLE vehicle (
  vehicle_id INT PRIMARY KEY AUTO_INCREMENT,
  customer_id INT NOT NULL,
  registration_no VARCHAR(20) UNIQUE NOT NULL,
  model VARCHAR(100),
  FOREIGN KEY (customer_id) REFERENCES customer(customer_id) ON DELETE CASCADE
);
CREATE TABLE service (
  service_id INT PRIMARY KEY AUTO_INCREMENT,
  service_name VARCHAR(100) NOT NULL UNIQUE,
  base_price DECIMAL(10,2) NOT NULL CHECK (base_price >= 0)
);
CREATE TABLE technician (
  technician_id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(15)
);
CREATE TABLE spare_part (
  part_id INT PRIMARY KEY AUTO_INCREMENT,
  part_name VARCHAR(100) NOT NULL UNIQUE,
  price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
  stock INT NOT NULL CHECK (stock >= 0)
);
CREATE TABLE booking (
  booking_id INT PRIMARY KEY AUTO_INCREMENT,
  vehicle_id INT NOT NULL,
  service_id INT NOT NULL,
  technician_id INT NULL,
  booking_date DATE NOT NULL,
  status ENUM('Booked','In Progress','Completed','Cancelled') NOT NULL DEFAULT 'Booked',
  FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id),
  FOREIGN KEY (service_id) REFERENCES service(service_id),
  FOREIGN KEY (technician_id) REFERENCES technician(technician_id)
);
CREATE TABLE job_part (
  booking_id INT NOT NULL,
  part_id INT NOT NULL,
  quantity INT NOT NULL CHECK (quantity > 0),
  PRIMARY KEY (booking_id, part_id),
  FOREIGN KEY (booking_id) REFERENCES booking(booking_id),
  FOREIGN KEY (part_id) REFERENCES spare_part(part_id)
);
CREATE TABLE invoice (
  invoice_id INT PRIMARY KEY AUTO_INCREMENT,
  booking_id INT NOT NULL UNIQUE,
  total DECIMAL(10,2) NOT NULL,
  status ENUM('Unpaid','Paid') NOT NULL DEFAULT 'Unpaid',
  gateway_order_id VARCHAR(40) NULL,
  issued_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES booking(booking_id)
);
CREATE TABLE payment (
  payment_id INT PRIMARY KEY AUTO_INCREMENT,
  invoice_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  method VARCHAR(30) NOT NULL,
  gateway_payment_id VARCHAR(40) NULL,
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (invoice_id) REFERENCES invoice(invoice_id)
);
CREATE TABLE status_log (
  log_id INT PRIMARY KEY AUTO_INCREMENT,
  booking_id INT NOT NULL,
  old_status VARCHAR(20),
  new_status VARCHAR(20),
  changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notification (
  notification_id INT PRIMARY KEY AUTO_INCREMENT,
  customer_id INT NOT NULL,
  message VARCHAR(255) NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customer(customer_id) ON DELETE CASCADE
);

CREATE INDEX idx_booking_date ON booking(booking_date);
CREATE INDEX idx_booking_status ON booking(status);
CREATE INDEX idx_notification_customer ON notification(customer_id, is_read);

CREATE VIEW v_booking_details AS
SELECT b.booking_id, v.customer_id, c.name AS customer_name, v.registration_no, v.model,
       s.service_name, s.base_price, b.technician_id, t.name AS technician_name,
       b.booking_date, b.status, i.invoice_id, i.total, i.status AS invoice_status
FROM booking b
JOIN vehicle v ON v.vehicle_id = b.vehicle_id
JOIN customer c ON c.customer_id = v.customer_id
JOIN service s ON s.service_id = b.service_id
LEFT JOIN technician t ON t.technician_id = b.technician_id
LEFT JOIN invoice i ON i.booking_id = b.booking_id;

DELIMITER //
CREATE TRIGGER trg_booking_status AFTER UPDATE ON booking FOR EACH ROW
BEGIN
  IF OLD.status <> NEW.status THEN
    INSERT INTO status_log(booking_id, old_status, new_status) VALUES (NEW.booking_id, OLD.status, NEW.status);
  END IF;
END//

CREATE PROCEDURE sp_generate_invoice(IN p_booking INT)
BEGIN
  DECLARE v_total DECIMAL(10,2) DEFAULT NULL;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
  START TRANSACTION;
  SELECT s.base_price + IFNULL((SELECT SUM(jp.quantity * sp.price) FROM job_part jp
                                JOIN spare_part sp ON sp.part_id = jp.part_id
                                WHERE jp.booking_id = b.booking_id), 0)
    INTO v_total
  FROM booking b JOIN service s ON s.service_id = b.service_id
  WHERE b.booking_id = p_booking AND b.status = 'Completed';
  IF v_total IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Booking must be Completed before invoicing';
  END IF;
  INSERT INTO invoice(booking_id, total) VALUES (p_booking, v_total);
  COMMIT;
END//
DELIMITER ;

INSERT INTO service(service_name, base_price) VALUES
 ('General Service',1500),('Oil Change',800),('Brake Inspection',1200),('Wheel Alignment',900),('AC Service',2200);
INSERT INTO technician(name, phone) VALUES ('Ravi Kumar','9000000001'),('Suresh Reddy','9000000002'),('Imran Khan','9000000003');
INSERT INTO spare_part(part_name, price, stock) VALUES
 ('Engine Oil 1L',450,50),('Oil Filter',250,40),('Brake Pad Set',1100,20),('Air Filter',350,30);
